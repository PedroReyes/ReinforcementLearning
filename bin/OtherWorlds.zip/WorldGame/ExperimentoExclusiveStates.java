package WorldGame;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JOptionPane;

import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.rosuda.REngine.Rserve.RConnection;

import Analysis.RCodeGenerator;
import Analysis.RLGraficar;
import Auxiliar.Helper;
import Output.Output;
import RL.RLWorld;
import RL.RLearner;
import RL.RLearner.LEARNING_METHOD;
import RL.RLearner.SELECTION_METHOD;

public class ExperimentoExclusiveStates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// ELAPSED TIME
		long tStart = System.nanoTime();

		// SHOWING TIME WHEN THE EXECUTION STARTED
		SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss.SSS");
		String current_time_str = time_formatter.format(System.currentTimeMillis());
		System.out.println(current_time_str);

		// Experimento
		int numeroDeExperimento = 0;
		String urlDelExperimento = Output.simulationPathExperimentosGameWorld[numeroDeExperimento];
		String descriptionDelExperimento = Output.simulationDescriptionExperimentosGameWorld[numeroDeExperimento];
		RL.RLearner.simulationPath = urlDelExperimento;
		RL.RLearner.simulationDescription = descriptionDelExperimento;
		boolean takeOnlyIntoAccountInRewardCalculationsLastRewardOfTheEpisode = true;

		// ================================
		// CONTANTS OF THE EXPERIMENT
		// ================================
		// Ejecutar el experimento y crear las graficas
		boolean ejecutarExperimento = true;
		boolean crearGraficasInternas = false; // el learner crea internamente ciertas graficas como las de la policy
		boolean crearGrafica = true;

		// Global parameters to any reinforcement learning experiment
		final int totalTasks = 20; // total de tareas
		final int totalEpisodes = 10; // total de episodios por ca da tarea

		// Learning and selection method
		LEARNING_METHOD learningMethod = LEARNING_METHOD.Q_LEARNING;
		SELECTION_METHOD selectionMethod = SELECTION_METHOD.E_GREEDY;

		// Learning method parameters
		final double learningRate = 1; // if selected Q_LEARNING, SARSA, TD(LAMBDA) methods
		final double discountedFactor = 1; // if selected Q_LEARNING, SARSA, TD(LAMBDA) methods
		final double lambdaBackup = 0.8; // if selected TD(lambda) methods

		// Selected method parameters
		final double epsilonSelection = 0.1; // if selected eGreedySelection
		final double[] epsilonRange = new double[] { epsilonSelection, 0 }; // if selected eGreedySelection
		final double cExploratoryParameterUCB = 1; // if selected UCB_selection
		final double temperatureSoftmax = 1; // if selected softmax selection
		final boolean baselineUsedSoftmax = true; // if selected softmax selection

		// ================================
		// PARAMETER THAT IS UNDER ANALISYS
		// ================================
		// PARAMETRO 1
		String nombreParametro1 = RLearner.LEARNING_PARAMETER.epsilonSelection.name();
		int divisionesParametro1 = 3;
		double[] epsilonValues = new double[divisionesParametro1];
		if (true) {
			epsilonValues[0] = 0.01;
			epsilonValues[1] = 0.1;
			epsilonValues[2] = 0.2;
		} else {
			for (int i = 1; i <= divisionesParametro1; i++) {
				double aux = Helper.round((1.0 / (double) (divisionesParametro1)) * ((double) i), Output.maxDecimales);
				epsilonValues[i - 1] = aux;
			}
		}

		// PARAMETRO 2 (THERE MAY NOT BE A SECOND PARAMETER TO EVALUATE)
		String nombreParametro2 = RLearner.LEARNING_PARAMETER.gammaDiscountFactor.name();
		int divisionesParametro2 = 5;
		double[] gammaValues = new double[divisionesParametro2];
		if (true) {
			gammaValues[0] = 0.0;
			gammaValues[0] = 0.0;
			gammaValues[1] = 0.01;
			gammaValues[2] = 0.1;
			gammaValues[3] = 0.2;
			gammaValues[4] = 1.0;
		} else {
			for (int i = 1; i <= divisionesParametro2; i++) {
				double aux = Helper.round((1.0 / (double) (divisionesParametro2)) * ((double) i), Output.maxDecimales);
				gammaValues[i - 1] = aux;
			}
		}

		// DEBUG DE COMBINACION DE PARAMETROS
		System.out.println("PARAMETRIZACIONES del experimento " + numeroDeExperimento + " (ejecucón del experimento_"
				+ (ejecutarExperimento ? "YES" : "NO") + ", crear graficas_" + (crearGrafica ? "YES" : "NO") + "):");
		System.out.println("[Tareas, Episodios] = " + "[" + totalTasks + ", " + totalEpisodes + "]");
		for (int i = 0; i < epsilonValues.length; i++) {
			for (int j = 0; j < gammaValues.length; j++) {
				System.out.println("[" + nombreParametro1 + ", " + nombreParametro2 + "] = " + "[" + epsilonValues[i]
						+ ", " + gammaValues[j] + "]");
			}
		}

		// ================================
		// EJECUCION DEL EXPERIMENTO
		// ================================
		if (ejecutarExperimento) {
			// ================================
			// STATES AND ACTIONS (if nothing is set, the actions and states will be the ones by default in the world)
			// ================================
			//Actions.Action[] actions = Actions.generateActions();
			//State[] states = MultiArmBanditWorld.generateStates(actions);

			// ================================
			// PERFORMANCE MEASURES
			// ================================
			double[][] performanceMeasures = new double[divisionesParametro1][divisionesParametro2];

			// ================================
			// THE LEARNER
			// ================================
			// Name of the files to be extracted the plots from
			List<String> fileSimulationNames = new LinkedList<>();

			// Executing the algorithm for several parameter values
			Thread[] parametrizaciones = new Thread[epsilonValues.length * gammaValues.length]; // +1 = epsilon temporal, el codigo esta insertado manualmente abajo
			for (int i = 0; i < epsilonValues.length; i++) {
				for (int j = 0; j < gammaValues.length; j++) {
					int indiceParametro1 = i;
					int indiceParametro2 = j;
					int indice = i * gammaValues.length + j;
					(parametrizaciones[indice] = new Thread() {
						public void run() {
							// ================================
							// THE WORLD
							// ================================
							RLWorld world;
							world = new GameWorldExclusiveStates(null, null);
							//							world = new MultiArmBanditWorld(null, null);

							// Executing the experiment
							executeExperiment(world, epsilonValues, indiceParametro1, gammaValues, indiceParametro2);
						}

						private void executeExperiment(RLWorld world, double[] experimentParameterValues1,
								int indiceParametro1, double[] experimentParameterValues2, int indiceParametro2) {
							// ================================
							// SETTING THE NAME OF THE FILE THAT IS CREATED
							// ================================
							String nombreSimulacion = Helper.generateFileName(totalTasks, totalEpisodes, learningMethod,
									selectionMethod, learningRate, discountedFactor, lambdaBackup, epsilonSelection,
									cExploratoryParameterUCB, temperatureSoftmax, baselineUsedSoftmax, nombreParametro1,
									nombreParametro2, world, experimentParameterValues1, indiceParametro1,
									experimentParameterValues2, indiceParametro2);

							// ================================
							// SETTING THE EXPERIMENT'S PARAMETERS
							// ================================
							RLearner learner = Helper.settingLearner(totalTasks, totalEpisodes, learningMethod,
									selectionMethod, learningRate, discountedFactor, lambdaBackup, epsilonSelection,
									cExploratoryParameterUCB, temperatureSoftmax, baselineUsedSoftmax, nombreParametro1,
									nombreParametro2, world, experimentParameterValues1, indiceParametro1,
									experimentParameterValues2, indiceParametro2, nombreSimulacion);

							// NOTA: INCLUIR ESTAS CONFIGURACIONES DENTRO DEL METODO ANTERIOR LLAMADO "settingLearner"
							learner.getOnlyLastReward = takeOnlyIntoAccountInRewardCalculationsLastRewardOfTheEpisode;
							learner.crearGraficasInternas = crearGraficasInternas;

							// ================================
							// RUNNING THE REINFORCEMENT
							// LEARNING ALGORITHM
							// ================================
							learner.runTrial();

							// ==================================
							// PERFORMANCE MEASURES ARE CAPTURED
							// ==================================
							performanceMeasures[indiceParametro1][indiceParametro2] = learner.performanceBasedOnRMSErrors == null
									? -1 : ((new Mean()).evaluate(learner.performanceBasedOnRMSErrors));
									//System.out.println("RMSE(alpha=" + experimentParameterValues1[indiceParametro1] + "): " + performanceMeasures[indiceParametro1][indiceParametro2]);

							// ==================================
							// SAVING SIMULATION NAME OF THE EXPERIMENT
							// ==================================
							synchronized (fileSimulationNames) {
								fileSimulationNames.add(nombreSimulacion);
							}
						}

					}).start();
				}
			}

			// ==============================================================
			// AQUI ESPERAMOS A QUE TODAS LAS HEBRAS SE TERMINEN DE EJECUTAR
			// ==============================================================
			System.out.println("=================================");
			System.out.println("WAITING FOR THE EXECUTING THREADS");
			System.out.println("=================================");
			for (int i = 0; i < epsilonValues.length; i++) {
				for (int j = 0; j < gammaValues.length; j++) {
					int indice = i * gammaValues.length + j;
					try {
						parametrizaciones[indice].join();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			// ==================================================================================
			// ELAPSED TIME
			// ==================================================================================
			long tEnd = System.nanoTime();
			long tDelta = tEnd - tStart;
			double elapsedSeconds = tDelta / 1000000000.0;

			System.out.println("==================================================================");
			System.out.println("(seconds) EXECUTION TIME FOR RUNNING TASKS AND EPISODES: " + elapsedSeconds);
			System.out.println("(minutes) EXECUTION TIME FOR RUNNING TASKS AND EPISODES: " + (elapsedSeconds / 60));
			System.out.println("==================================================================");

			// ===============================================================================
			// ALMACENAMOS LOS RESULTADOS DE RENDIMIENTO PARA LAS DIFERENTES PARAMETRIZACIONES
			// Nota: por cada parametrizacion se obtiene solo un unico dato, RMSE, que mide
			// el error producido de media entre la estimacion producida por el algoritmo
			// y la politica optima. Evidentemente, si se quiere obtener este dato ha de saberse
			// cual es la politica optima y, consecuentemente, implementarla en el objeto World.
			// ===============================================================================
			// Showing the results
			String performance = "";
			System.out.println("=================================================");
			performance = ";";
			for (int j = 0; j < gammaValues.length; j++) {
				performance = performance + "(" + nombreParametro2 + "=" + gammaValues[j] + ") ";
				performance = performance + (j + 1 == gammaValues.length ? "" : ";");
			}
			performance = performance + "\n";

			for (int i = 0; i < epsilonValues.length; i++) {
				performance = performance + "(" + nombreParametro1 + "=" + epsilonValues[i] + "); ";
				for (int j = 0; j < gammaValues.length; j++) {
					performance = performance + Helper.round(performanceMeasures[i][j], Output.maxDecimales);
					performance = performance + (j + 1 == gammaValues.length ? "" : ";");
				}
				performance = performance + "\n";
			}
			System.out.println(performance);
			System.out.println("=================================================");
			try {
				Helper.writeToFile(performance,
						urlDelExperimento + "/" + Output.typeOfCharts.policyPerformance + ".csv");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// ================================
		// GRAFICAS DEL EXPERIMENTO
		// ================================
		if (crearGrafica) {
			System.out.println("======================");
			System.out.println("Creating the charts...");
			System.out.println("======================");
			boolean chooseFiles;
			RLGraficar graficar = new RLGraficar(chooseFiles = false);

			// Checking R connection with Rserve
			try {
				new RConnection();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Sep up Rserve: goes to R class Analysis->SetUpRserve.R and run it",
						"Rserve not setup", JOptionPane.ERROR_MESSAGE);
			}

			// File that must not be taken into account
			String[] specificFileToNotPlot = new String[] { Output.typeOfCharts.policyPerformance.name() };

			// Por algun extrano motivo Windows no realiza una nueva conexion para cada conexion con Rserve por lo que
			// no se puedan usar Threads en windows para maximizar la creacion de graficas
			if (RCodeGenerator.isOperativeSystemWindows()) {
				System.out.println("1");
				graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yAverageReward, null, null);
				System.out.println("2");
				graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yOptimalAction, null, null);
				System.out.println("3");
				graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yPercentageOfActions, null, null);
			} else {
				// AVERAGE REWARD
				new Thread() {

					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yAverageReward, null,
								specificFileToNotPlot);
					}
				}.start();

				if (true) {
					// AVERAGE STEPS NEEDED PER EPISODE
					new Thread() {
						public void run() {
							graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yAverageSteps, null,
									specificFileToNotPlot);
						}
					}.start();

					// OPTIMAL ACTION
					new Thread() {
						public void run() {
							graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yOptimalAction, null,
									specificFileToNotPlot);
						}
					}.start();

					// HISTOGRAM OF ACTIONS PERCENTAGE PER EACH LEARNER
					//for (Iterator<String> iterator = fileSimulationNames.iterator(); iterator.hasNext();) {
					String fileName = null;//(String) iterator.next();
					new Thread() {
						public void run() {
							graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yPercentageOfActions,
									fileName, specificFileToNotPlot);
						}
					}.start();
					//}

					// PERFORMANCE MEASURED IN TERMS OF VICTORIES
					new Thread() {
						public void run() {
							graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yWinProbability, null,
									specificFileToNotPlot);
						}
					}.start();

					// PERFORMANCE MEASURED IN RMS ERROR USING AN OPTIMAL POLICY, IF EXIST
					new Thread() {
						public void run() {
							graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.policyPerformance,
									Output.typeOfCharts.policyPerformance.name(), null);
						}
					}.start();
				}
			}
		}

	}

}
