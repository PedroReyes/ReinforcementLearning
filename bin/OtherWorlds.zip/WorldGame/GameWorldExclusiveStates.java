package WorldGame;

import java.awt.Point;
import java.util.Random;

import Auxiliar.GameMap;
import Auxiliar.Helper;
import Output.Output;
import RL.Action;
import RL.RLPolicy;
import RL.RLWorld;
import RL.State;

public class GameWorldExclusiveStates implements RLWorld {

	int cont = 0;
	int aux = 0;

	// AGENT
	double agentFullLife = 10.0;
	double agentLife = agentFullLife;
	double agentDamage = 1.0; // positive reward each time we attack the enemy

	// ENEMY
	double enemyFullLife = 20.0;
	double enemyLife = enemyFullLife;
	double enemyDamage = 1.0; // negative reward each time the enemy hurts us

	// VICTORY STATES
	public State[] victoryStates = new State[] { new State(new double[] { STATES.ENEMIGO_DESTRUIDO.ordinal() },
			STATES.ENEMIGO_DESTRUIDO.ordinal(), STATES.ENEMIGO_DESTRUIDO.name()) };//new int[] { STATES.ENEMIGO_DESTRUIDO.ordinal() };

	// ACTIONS AND STATES
	// Use this in case it is suitable to write the state or actions manually, otherwise you will
	// have to go to methods "generateState" or "generateActions" in and do it programatically in case you cant
	public static enum ACTIONS {
		IR_ZONA_REPARACION, IR_ZONA_SEGURA, ATACAR, IR_ZONA_ANTIBOMBARDEOS
	};

	// ESTADOS EXCLUSIVOS, LAS UNICAS COMBINACIONES SON LA VIDA DEL AGENTE CON LOS DIFERENTES ESTADOS
	public static enum STATES {
		// EXCLUSIVE STATES (only combinations with the life of the agent)
		VIDA_ALTA_ZONA_SEGURA, VIDA_BAJA_ZONA_SEGURA, // 1. ATACAR, IR_ZONA_REPARACION
		VIDA_ALTA_ZONA_REPARACION, VIDA_BAJA_ZONA_REPARACION, // 2. ATACAR, ATACAR
		VIDA_ALTA_ZONA_ANTIBOMBARDEOS, VIDA_BAJA_ZONA_ANTIBOMBARDEOS, // 3. ATACAR, IR_ZONA_REPARACION
		VIDA_ALTA_ZONA_ATAQUE, VIDA_BAJA_ZONA_ATAQUE, // 4. ATACAR, IR_ZONA_REPARACION
		VIDA_ALTA_ZONA_PELIGROSA, VIDA_BAJA_ZONA_PELIGROSA, // 5. ATACAR, IR_ZONA_REPARACION
		VIDA_ALTA_BOMBARDEO_DETECTADO, VIDA_BAJA_BOMBARDEO_DETECTADO, // 6. IR_ZONA_ANTIBOMBARDEOS, IR_ZONA_ANTIBOMBARDEOS

		// TERMINAL STATES
		AGENTE_DESTRUIDO, ENEMIGO_DESTRUIDO
	};

	// OPTIMAL POLICY (for analisys purposes, must be normalized to 1 and 0s)
	RLPolicy optimalPolicy;

	//	static int[][] policyTrueValues = null;//
	static int[][] policyTrueValues = new int[][] { //
			//[ 1 ][  2 ][  3 ][ 4 ][  5  ][ 6  ]
			{ 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0 }, // Action - IR_ZONA_REPARACION
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // Action - IR_ZONA_SEGURA
			{ 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0 }, // Action - ATACAR
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1 } // Action - IR_ZONA_ANTIBOMBARDEOS 
	};

	// Debugging
	boolean debug = false;

	// Random variable for statistical purposes
	Random random;

	// For analysis purposes
	public Action optimalAction;

	// Specific RL attributes
	State[] states;
	Action[] actions;
	public double initPolicyValues;

	// Auxiliar variable
	int actionExecuted; // action that is executed for the current or last state, depending the perspective we look at it

	// Special attributes of the problem

	// The reward that is giving after an action is being carried out
	double waitingReward;
	int currentState;
	int nextState;

	public GameWorldExclusiveStates(State[] states, Action[] actions) {
		// STATES AND ACTIONS ARE OWN OF THE WORLD
		if (actions == null)
			actions = generateActions();

		if (states == null)
			states = generateStates(actions);

		// SEEDS FOR RANDOM VARIABLES
		int seed = 1000;

		// OPTIMAL POLICY (for analisys purposes)
		optimalPolicy = new RLPolicy(states, actions);

		// GENERAL
		this.states = states;
		this.actions = actions;
		this.random = new Random(seed);

		// THE PROBLEM (giving random values)
		initPolicyValues = 0;
		optimalAction = actions[ACTIONS.ATACAR.ordinal()];//Actions.Action.tirarPalanca_3;
		resetState();

		if (debug)
			System.out.println("Optimal action: " + this.optimalAction.name());
	}

	/******* RLWorld interface functions ***********/
	@Override
	public State getNextState(int action) {
		// TODO Auto-generated method stub
		// Just for debuggin purposes this line is
		actionExecuted = action;
		currentState = nextState;

		// =============================================================
		// Reset the reward
		// =============================================================
		waitingReward = 0;

		// =============================================================
		// Optimal action
		// =============================================================
		if (currentState == STATES.VIDA_ALTA_BOMBARDEO_DETECTADO.ordinal()
				|| currentState == STATES.VIDA_BAJA_BOMBARDEO_DETECTADO.ordinal())
			optimalAction = actions[ACTIONS.IR_ZONA_ANTIBOMBARDEOS.ordinal()];

		else if (currentState == STATES.VIDA_ALTA_ZONA_REPARACION.ordinal()
				|| currentState == STATES.VIDA_BAJA_ZONA_REPARACION.ordinal()
				|| currentState == STATES.VIDA_ALTA_ZONA_SEGURA.ordinal()
				|| currentState == STATES.VIDA_ALTA_ZONA_ATAQUE.ordinal())
			optimalAction = actions[ACTIONS.ATACAR.ordinal()];

		else if (currentState == STATES.VIDA_BAJA_ZONA_SEGURA.ordinal()
				|| currentState == STATES.VIDA_BAJA_ZONA_ATAQUE.ordinal()
				|| currentState == STATES.VIDA_ALTA_ZONA_PELIGROSA.ordinal()
				|| currentState == STATES.VIDA_BAJA_ZONA_PELIGROSA.ordinal())
			optimalAction = actions[ACTIONS.IR_ZONA_REPARACION.ordinal()];

		else if (currentState == STATES.VIDA_ALTA_ZONA_ANTIBOMBARDEOS.ordinal()
				|| currentState == STATES.VIDA_BAJA_ZONA_ANTIBOMBARDEOS.ordinal())
			optimalAction = null;//actions[ACTIONS.IR_ZONA_ANTIBOMBARDEOS.ordinal()]; // you are dead anyway

		// =============================================================
		// Next state
		// =============================================================
		// IR_ZONA_SEGURA
		if (action == ACTIONS.IR_ZONA_SEGURA.ordinal()) {
			// NEXT STATE
			nextState = agentLife >= agentFullLife / 2.0 ? STATES.VIDA_ALTA_ZONA_SEGURA.ordinal()
					: STATES.VIDA_BAJA_ZONA_SEGURA.ordinal();
		}
		// IR_ZONA_REPARACION
		else if (action == ACTIONS.IR_ZONA_REPARACION.ordinal()) {
			// NEXT STATE
			nextState = agentLife >= agentFullLife / 2.0 ? STATES.VIDA_ALTA_ZONA_REPARACION.ordinal()
					: STATES.VIDA_BAJA_ZONA_REPARACION.ordinal();

			// NEW HEALTH OF THE AGENT AND THE ENEMY
			agentLife = agentFullLife;
		}
		// ATACAR
		else if (action == ACTIONS.ATACAR.ordinal()) {
			// NEW HEALTH OF THE AGENT AND THE ENEMY
			agentLife = agentLife - enemyDamage < 0 ? 0 : agentLife - enemyDamage;
			enemyLife = enemyLife - agentDamage < 0 ? 0 : enemyLife - agentDamage;

			// NEXT STATE
			nextState = agentLife >= (agentFullLife / 2.0) ? STATES.VIDA_ALTA_ZONA_ATAQUE.ordinal()
					: STATES.VIDA_BAJA_ZONA_ATAQUE.ordinal();
		}
		// IR_ZONA_ANTIBOMBARDEOS
		else if (action == ACTIONS.IR_ZONA_ANTIBOMBARDEOS.ordinal()) {

			// NEXT STATE
			nextState = agentLife >= (agentFullLife / 2.0) ? STATES.VIDA_ALTA_ZONA_ANTIBOMBARDEOS.ordinal()
					: STATES.VIDA_BAJA_ZONA_ANTIBOMBARDEOS.ordinal();
		} else {
			throw new IllegalArgumentException("Error: the action does not exist");
		}

		// =============================================================
		// Current state influence over the agent right now
		// =============================================================
		if (((currentState == STATES.VIDA_ALTA_BOMBARDEO_DETECTADO.ordinal()
				|| currentState == STATES.VIDA_BAJA_BOMBARDEO_DETECTADO.ordinal())
				&& action != ACTIONS.IR_ZONA_ANTIBOMBARDEOS.ordinal())) {
			// If an air attack is detected and we are not in the zone anti-air attacks, we will die.
			agentLife = 0;
		}

		// =============================================================
		// A % of the time the enemy throws air attacks and dangerous zone
		// =============================================================
		double probabilityOfAirAttack = 0.90;
		double probabilityOfDangerousZone = 0.90;
		if (Math.random() > probabilityOfAirAttack) {
			nextState = (agentLife >= (agentFullLife / 2.0)) ? STATES.VIDA_ALTA_BOMBARDEO_DETECTADO.ordinal()
					: STATES.VIDA_BAJA_BOMBARDEO_DETECTADO.ordinal();
		} else if (Math.random() > probabilityOfDangerousZone) {
			nextState = (agentLife >= (agentFullLife / 2.0)) ? STATES.VIDA_ALTA_ZONA_PELIGROSA.ordinal()
					: STATES.VIDA_BAJA_ZONA_PELIGROSA.ordinal();
		}

		// =============================================================
		// The next state change depending on the agents and enemy lifes
		// =============================================================
		if (agentLife == 0) {
			// NEXT STATE
			nextState = STATES.AGENTE_DESTRUIDO.ordinal();

			// REWARD
			waitingReward = Helper.round(-1, Output.maxDecimales);
		} else if (enemyLife == 0) {
			// NEXT STATE
			nextState = STATES.ENEMIGO_DESTRUIDO.ordinal();

			// REWARD
			waitingReward = Helper.round(+1, Output.maxDecimales);
		} else {
			// REWARD
			waitingReward = Helper.round(+0, Output.maxDecimales);
		}

		if (false) {
			System.out.println("Life: " + agentLife + "> Current state: " + STATES.values()[currentState]
					+ " > Action: " + ACTIONS.values()[action] + " > Next state: " + STATES.values()[nextState]
					+ " > reward: " + waitingReward);
		}

		return new State(new double[] { nextState }, nextState, STATES.values()[nextState].name());//new int[] { nextState };
	}

	@Override
	public boolean validAction(int action) {
		// TODO Auto-generated method stub
		return true; // every action is valid
	}

	@Override
	public boolean endState() {
		// TODO Auto-generated method stub
		// The game is finished when the agent or the enemy dies
		return nextState == STATES.AGENTE_DESTRUIDO.ordinal() || currentState == STATES.ENEMIGO_DESTRUIDO.ordinal();
	}

	@Override
	public State resetState() {
		// TODO Auto-generated method stub
		agentLife = agentFullLife;
		enemyLife = enemyFullLife;
		STATES resetState = STATES.VIDA_ALTA_ZONA_SEGURA;
		currentState = resetState.ordinal();
		nextState = resetState.ordinal();
		return new State(new double[] { resetState.ordinal() }, resetState.ordinal(), resetState.name());//new int[] { resetState.ordinal() };
	}

	@Override
	public State[] generateStates(Action[] actions) {
		// TODO Auto-generated method stub
		State[] result = new State[STATES.values().length];
		STATES[] statesEnum = STATES.values();
		//		for (int i = 0; i < statesEnum.length; i++) {
		//			result[i] = new State(i, statesEnum[i].name());
		//		}

		return result;
	}

	@Override
	public Action[] generateActions() {
		// TODO Auto-generated method stub
		Action[] result = new Action[ACTIONS.values().length];
		ACTIONS[] actions = ACTIONS.values();
		for (int i = 0; i < actions.length; i++) {
			result[i] = new Action(i, actions[i].name());
		}

		return result;
	}

	// ===========================
	// GETTERS & SETTERS
	// ===========================
	@Override
	public int[] getDimension() {
		// TODO Auto-generated method stub
		return new int[] { states.length, actions.length };
	}

	@Override
	public double getReward() {
		// TODO Auto-generated method stub
		return waitingReward;//new double[] { waitingReward };
	}

	@Override
	public State[] getStates() {
		// TODO Auto-generated method stub
		return states;
	}

	@Override
	public Action[] getActions() {
		// TODO Auto-generated method stub
		return actions;
	}

	public void setStates(State[] states) {
		this.states = states;
	}

	public void setActions(Action[] actions) {
		this.actions = actions;
	}

	@Override
	public Action getOptimalAction() {
		return optimalAction;
	}

	public void setOptimalAction(Action optimalAction) {
		this.optimalAction = optimalAction;
	}

	@Override
	public double getInitValues() {
		// TODO Auto-generated method stub
		return initPolicyValues;
	}

	@Override
	public void setInitValues(double initValue) {
		// TODO Auto-generated method stub
		this.initPolicyValues = initValue;
	}

	@Override
	public RLPolicy getOptimalPolicy() {
		// TODO Auto-generated method stub
		if (policyTrueValues != null) {
			for (int action = 0; action < policyTrueValues.length; action++) {
				for (int state = 0; state < policyTrueValues[0].length; state++) {
					optimalPolicy.setQValue(state, action, policyTrueValues[action][state]);
				}
			}

			return optimalPolicy;
		} else {
			return null;
		}
	}

	@Override
	public State[] getVictoryStates() {
		// TODO Auto-generated method stub
		return victoryStates;
	}

	@Override
	public String getCurrentGeneralState() {
		// TODO Auto-generated method stub
		return "Agent Life: " + agentLife + "Enemy life: " + enemyLife // Agent and enemy life 
				+ " > Current state: " + STATES.values()[currentState].name()// (the current state may be more than one state) + STATES.values()[currentState]
				+ " > Action: " + ACTIONS.values()[actionExecuted]// Action 
				+ " > Next state: " + STATES.values()[nextState].name()// (the next state may be more than one state) + STATES.values()[nextState]
				+ " > reward: " + waitingReward;//
	}

	@Override
	public State[] generateVictoryStates() {
		// TODO Auto-generated method stub
		return null;
	}

	// ===================================
	// AUXILIAR METHODS FOR GUI PURPOSES
	// ===================================
	@Override
	public GameMap getGameMap() {
		return null;
	}

	@Override
	public double getAgentLife() {
		return agentLife;
	}

	@Override
	public double getAgentFullLife() {
		return agentFullLife;
	}

	@Override
	public double getEnemyLife() {
		return enemyLife;
	}

	@Override
	public double getEnemyFullLife() {
		return enemyFullLife;
	}

	@Override
	public Point getAgentPosition() {
		return null;
	}

	@Override
	public State getCurrentState() {
		return null;
	}

	@Override
	public Action[] findLegalActions(State state) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public State getNextState(State state, int action) {
		return null;
	}

	@Override
	public boolean endState(State state) {
		return false;
	}

	@Override
	public void saveState() {

	}

	@Override
	public void resetToLastSavedState() {

	}

	@Override
	public RLWorld generateCopy() {
		// TODO Auto-generated method stub
		return null;
	}
}
