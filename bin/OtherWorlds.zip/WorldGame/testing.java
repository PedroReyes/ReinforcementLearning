package WorldGame;

public class testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//		System.out.println(STATES.values()[STATES.VIDA_BAJA.ordinal()]);

		//		System.out.println(RLearner.LEARNING_METHOD.valueOf("fd"));

		System.out.println(Math.pow(0, 0));
		System.out.println(0 / 1);
	}

}
