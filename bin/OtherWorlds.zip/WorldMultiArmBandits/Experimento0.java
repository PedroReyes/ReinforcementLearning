package WorldMultiArmBandits;

import javax.swing.JOptionPane;

import org.rosuda.REngine.Rserve.RConnection;

import Analysis.RCodeGenerator;
import Analysis.RLGraficar;
import RL.RLearner;
import RL.RLearner.LEARNING_METHOD;
import RL.RLearner.SELECTION_METHOD;

public class Experimento0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Experimento
		int numeroDeExperimento = 0;
		String urlDelExperimento = Output.Output.simulationPathExperimentosMultiarmBanditWorld[numeroDeExperimento];
		String descriptionDelExperimento = Output.Output.simulationDescriptionExperimentosMultiarmBanditWorld[numeroDeExperimento];
		RL.RLearner.simulationPath = urlDelExperimento;
		RL.RLearner.simulationDescription = descriptionDelExperimento;

		// Ejecutar el experimento y crear las graficas
		boolean ejecutarExperimento = true;
		boolean crearGrafica = true;

		// ================================
		// EJECUCION DEL EXPERIMENTO
		// ================================
		if (ejecutarExperimento) {
			// ================================
			// STATES AND ACTIONS (if nothing is set, the actions and states will be the ones by default in the world)
			// ================================
			//Actions.Action[] actions = Actions.generateActions();
			//State[] states = MultiArmBanditWorld.generateStates(actions);

			// ================================
			// THE WORLD
			// ================================
			MultiArmBanditWorld tttWorld = new MultiArmBanditWorld(null, null);

			// ================================
			// THE LEARNER
			// ================================
			int totalTasks = 2; // total de tareas
			int totalEpisodes = 5; // total de episodios por cada tarea
			double[] epsilonGreedy = new double[] { 0.0, 0.01, 0.1 }; // epsilon - seleccion eGreedy

			// Executing the algorithm for several parameter values
			Thread[] parametrizaciones = new Thread[epsilonGreedy.length]; // +1 = epsilon temporal, el codigo esta insertado manualmente abajo
			for (int i = 0; i < epsilonGreedy.length; i++) {
				int indice = i;
				(parametrizaciones[indice] = new Thread() {
					public void run() {
						executeExperiment(tttWorld, totalTasks, totalEpisodes, epsilonGreedy, indice);
					}

					private void executeExperiment(MultiArmBanditWorld tttWorld, int totalTasks, int totalEpisodes,
							double[] epsilonGreedy, int indice) {
						String worldName = tttWorld.getClass().toString()
								.substring(tttWorld.getClass().toString().lastIndexOf(".") + 1);
						System.out.println(worldName);
						String nombreSimulacion = worldName + "_t" + totalTasks + "_ep" + totalEpisodes + "_eG"
								+ epsilonGreedy[indice];

						// ================================
						// SETTING THE EXPERIMENT'S PARAMETERS
						// ================================
						RLearner learner = new RLearner(nombreSimulacion, tttWorld);
						learner.setTasks(totalTasks);
						learner.setTotalEpisodes(totalEpisodes);
						learner.setEpsilon(epsilonGreedy[indice]);
						learner.setActionSelectionMethod(SELECTION_METHOD.E_GREEDY);
						learner.setLearningMethod(LEARNING_METHOD.SARSA);

						// ================================
						// RUNNING THE REINFORCEMENT
						// LEARNING ALGORITHM
						// ================================
						learner.runTrial();
					}
				}).start();
			}

			// AQUI UN ESPERAR A QUE TODAS LAS HEBRAS SE TERMINEN DE EJECUTAR
			for (int i = 0; i < parametrizaciones.length; i++) {
				try {
					parametrizaciones[i].join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		// ================================
		// GRAFICAS DEL EXPERIMENTO
		// ================================
		if (crearGrafica) {
			//System.out.println("Creating the charts...");
			boolean chooseFiles = false;
			RLGraficar graficar = new RLGraficar(chooseFiles);

			// Checking R connection with Rserve
			try {
				new RConnection();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Sep up Rserve: goes to R class Analysis->SetUpRserve.R and run it",
						"Rserve not setup", JOptionPane.ERROR_MESSAGE);
			}

			// Por algun extrano motivo Windows no realiza una nueva conexion para cada conexion con Rserve por lo que
			// no se puedan usar Threads en windows para maximizar la creacion de graficas
			if (RCodeGenerator.isOperativeSystemWindows()) {
				System.out.println("1");
				graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yAverageReward, null, null);
				System.out.println("2");
				graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yOptimalAction, null, null);
				System.out.println("3");
				graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yPercentageOfActions, null, null);
			} else {
				// AVERAGE REWARD
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yAverageReward, null,
								null);
					}
				}.start();

				// OPTIMAL ACTION
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yOptimalAction, null,
								null);
					}
				}.start();

				// HISTOGRAM OF ACTIONS
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yPercentageOfActions, null,
								null);
					}
				}.start();
			}
		}
	}

}
