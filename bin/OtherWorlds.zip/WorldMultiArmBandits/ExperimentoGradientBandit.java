package WorldMultiArmBandits;

import javax.swing.JOptionPane;

import org.rosuda.REngine.Rserve.RConnection;

import Analysis.RCodeGenerator;
import Analysis.RLGraficar;
import RL.RLearner;
import RL.RLearner.LEARNING_METHOD;
import RL.RLearner.SELECTION_METHOD;

public class ExperimentoGradientBandit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Experimento
		int numeroDeExperimento = 4;
		String urlDelExperimento = Output.Output.simulationPathExperimentosMultiarmBanditWorld[numeroDeExperimento];
		String descriptionDelExperimento = Output.Output.simulationDescriptionExperimentosMultiarmBanditWorld[numeroDeExperimento];
		RL.RLearner.simulationPath = urlDelExperimento;
		RL.RLearner.simulationDescription = descriptionDelExperimento;

		// Ejecutar el experimento y crear las graficas
		boolean ejecutarExperimento = true;
		boolean crearGrafica = true;

		// ================================
		// EJECUCION DEL EXPERIMENTO
		// ================================
		if (ejecutarExperimento) {
			// ================================
			// STATES AND ACTIONS  (if nothing is set, the actions and states will be the ones by default in the world)
			// ================================
			//Actions.Action[] actions = Actions.generateActions();
			//State[] states = MultiArmBanditWorld.generateStates(actions);

			// ================================
			// THE LEARNER
			// ================================
			int totalTasks = 2000; // total de tareas
			int totalEpisodes = 1000; // total de episodios por cada tarea
			double[] stepSizeParameter = new double[] { 0.1, 0.1, 0.4, 0.4 }; // epsilon - seleccion eGreedy
			double temperature = 1.0;

			// Executing the algorithm for several parameter values
			Thread[] parametrizaciones = new Thread[stepSizeParameter.length]; // +1 = metodo de seleccion UCB, el codigo esta insertado manualmente abajo
			for (int i = 0; i < stepSizeParameter.length; i++) {
				int indice = i;
				(parametrizaciones[indice] = new Thread() {
					public void run() {
						// ================================
						// THE WORLD
						// ================================
						MultiArmBanditWorld tttWorld = new MultiArmBanditWorld(null, null);

						// Execute the experiment
						executeExperiment(tttWorld, totalTasks, totalEpisodes, stepSizeParameter, indice);
					}

					private void executeExperiment(MultiArmBanditWorld tttWorld, int totalTasks, int totalEpisodes,
							double[] evaluatedParameter, int indice) {
						boolean baselineUsed = indice % 2 == 0 ? true : false;
						String nombreSimulacion = "MultiArmBandit_Problem_t" + totalTasks + "_ep" + totalEpisodes
								+ "_alpha" + evaluatedParameter[indice] + "_" + (baselineUsed ? "with" : "without")
								+ "Baseline";

						// ================================
						// SETTING THE EXPERIMENT'S PARAMETERS
						// ================================
						RLearner learner = new RLearner(nombreSimulacion, tttWorld);
						learner.setTasks(totalTasks);
						learner.setTotalEpisodes(totalEpisodes);
						learner.setAlpha(stepSizeParameter[indice]);
						learner.setLearningMethod(LEARNING_METHOD.GRADIENT_BANDIT);
						learner.setTemperature(temperature);
						learner.setActionSelectionMethod(SELECTION_METHOD.SOFT_MAX);
						learner.setBaselineUsed(baselineUsed);

						// ================================
						// RUNNING THE REINFORCEMENT
						// LEARNING ALGORITHM
						// ================================
						learner.runTrial();
					}
				}).start();
			}

			// ==============================================================
			// AQUI UN ESPERAR A QUE TODAS LAS HEBRAS SE TERMINEN DE EJECUTAR
			// ==============================================================
			for (int i = 0; i < parametrizaciones.length; i++) {
				try {
					parametrizaciones[i].join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		// ================================
		// GRAFICAS DEL EXPERIMENTO
		// ================================
		if (crearGrafica) {
			System.out.println("Creating the charts...");
			boolean chooseFiles = false;
			RLGraficar graficar = new RLGraficar(chooseFiles);

			// Checking R connection with Rserve
			try {
				new RConnection();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Set up Rserve: goes to R class Analysis->SetUpRserve.R and run it",
						"Rserve not setup", JOptionPane.ERROR_MESSAGE);
			}

			// Por algun extrano motivo Windows no realiza una nueva conexion para cada conexion con Rserve por lo que
			// no se puedan usar Threads en windows para maximizar la creacion de graficas
			if (RCodeGenerator.isOperativeSystemWindows()) {
				System.out.println("1");
				graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yAverageReward, null, null);
				System.out.println("2");
				graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yOptimalAction, null, null);
				System.out.println("3");
				graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yPercentageOfActions, null, null);
			} else {
				// AVERAGE REWARD
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yAverageReward, null,
								null);
					}
				}.start();

				// OPTIMAL ACTION
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yOptimalAction, null,
								null);
					}
				}.start();

				// HISTOGRAM OF ACTIONS
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.Output.typeOfCharts.xEpisode_yPercentageOfActions, null,
								null);
					}
				}.start();
			}
		}
	}

}
