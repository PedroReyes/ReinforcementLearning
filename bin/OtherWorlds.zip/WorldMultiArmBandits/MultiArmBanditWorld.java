package WorldMultiArmBandits;

import java.awt.Point;
import java.util.Random;

import Auxiliar.GameMap;
import Auxiliar.Helper;
import RL.Action;
import RL.RLPolicy;
import RL.RLWorld;
import RL.State;
import WorldGame.GameWorldExclusiveStates.ACTIONS;

public class MultiArmBanditWorld implements RLWorld {

	// Random variable for statistical purposes
	Random random;

	// For analysis purposes
	public Action optimalAction;

	// Specific RL attributes
	State lastState; // in this world there is only one state so this variable is not used on this world
	State[] states;
	Action[] actions;
	public double initPolicyValues;

	// Special attributes of the problem
	Random[] randomInstances;
	public double[] meanValues;
	static double deviation = 1;

	// Random r;
	double waitingReward;

	// Auxiliar variable
	int actionExecuted; // action that is executed for the current or last state, depending the perspective we look at it

	public MultiArmBanditWorld(State[] states, Action[] actions) {
		// STATES AND ACTIONS ARE OWN OF THE WORLD
		if (actions == null)
			actions = generateActions();

		if (states == null)
			states = generateStates(actions);

		// SEEDS FOR RANDOM VARIABLES
		int seedForMeans = 1000;
		//int seedForBanditRewardDeviation = 345;

		// GENERAL
		this.states = states;
		this.actions = actions;
		this.random = new Random(seedForMeans);
		this.initPolicyValues = 0;

		// THE PROBLEM (giving random values)
		// Auxiliar variables to set the best action
		double bestMeanValue = 0;

		// mean values
		this.meanValues = new double[actions.length];
		this.randomInstances = new Random[actions.length];
		boolean debug = false;
		if (debug)
			System.out.println("Mean values:");
		for (int i = 0; i < actions.length; i++) {
			// Creating random instances for returning random deviations in
			// rewards
			this.randomInstances[i] = new Random();//seedForBanditRewardDeviation);

			// Giving means randoms
			this.meanValues[i] = this.random.nextDouble();

			if (debug)
				System.out.println("Action " + actions[i].toString() + ": " + meanValues[actions[i].ordinal()]);

			// Checking the best action up to now
			if (this.meanValues[i] > bestMeanValue) {
				bestMeanValue = this.meanValues[i];
				this.optimalAction = actions[i];
			}
		}

		if (debug)
			System.out.println("Optimal action: " + this.optimalAction.name());

		// Specific example of the book
		initPolicyValues = 0;
		meanValues = new double[] { 1, -0.8, 1.55, 0.6, 1.2, -1.5, -0.2, -1.1, 0.9, -0.6 };
		optimalAction = actions[2];//Actions.Action.tirarPalanca_3;
	}

	/******* RLWorld interface functions ***********/
	@Override
	public int[] getDimension() {
		// TODO Auto-generated method stub
		return new int[] { states.length, actions.length };
	}

	@Override
	public State getNextState(int action) {
		// TODO Auto-generated method stub
		// Just for debuggin purposes this line is
		actionExecuted = action;

		boolean useRewardsWithDeviation = true;
		if (useRewardsWithDeviation) {
			// Fix values plus positive or negative reward
			double randomReward = this.randomInstances[action].nextDouble() * deviation;
			waitingReward = meanValues[action]
					+ (this.randomInstances[action].nextDouble() > 0.5 ? +randomReward : -randomReward);

			//waitingReward = (new Random()).nextDouble() > 0.5 ? +(new Random()).nextDouble() : -(new Random()).nextDouble();
			// waitingReward = waitingReward < 0 ? 0 : waitingReward;
		} else {
			// Fix values
			waitingReward = meanValues[action];
		}

		// Round the reward
		waitingReward = Helper.round(waitingReward, 3);

		return new State(new double[] { 0 }, 0, actions.length + "-armed");// in the multiarm problem there is only one state
	}

	@Override
	public double getReward() {
		// TODO Auto-generated method stub
		return waitingReward;//new double[] { waitingReward };
	}

	@Override
	public boolean validAction(int action) {
		// TODO Auto-generated method stub
		return true; // every action is valid
	}

	@Override
	public boolean endState() {
		// TODO Auto-generated method stub
		return true; // each action in the multiarm problem is a final state
	}

	@Override
	public State resetState() {
		// TODO Auto-generated method stub
		return new State(new double[] { 0 }, 0, actions.length + "-armed");
	}

	@Override
	public double getInitValues() {
		// TODO Auto-generated method stub
		return initPolicyValues;
	}

	@Override
	public void setInitValues(double initValue) {
		// TODO Auto-generated method stub
		this.initPolicyValues = initValue;
	}

	// ================================
	// AUXILIAR METHODS
	// ================================

	// ===========================
	// GETTERS & SETTERS
	// ===========================
	@Override
	public State[] getStates() {
		// TODO Auto-generated method stub
		return states;
	}

	@Override
	public Action[] getActions() {
		// TODO Auto-generated method stub
		return actions;
	}

	public void setStates(State[] states) {
		this.states = states;
	}

	public void setActions(Action[] actions) {
		this.actions = actions;
	}

	@Override
	public Action getOptimalAction() {
		return optimalAction;
	}

	public void setOptimalAction(Action optimalAction) {
		this.optimalAction = optimalAction;
	}

	@Override
	public State[] generateStates(Action[] actions) {
		// TODO Auto-generated method stub
		//State[] states = new State[] { new State(0, (actions.length + "_armed")) };
		State[] states = new State[] { new State(new double[] { 0 }, 0, actions.length + "-armed") };

		return states;
	}

	@Override
	public Action[] generateActions() {
		// TODO Auto-generated method stub
		Action[] actions = new Action[10];

		for (int i = 0; i < actions.length; i++) {
			actions[i] = new Action(i, "tirarPalanca" + (i + 1));
		}

		return actions;
	}

	@Override
	public RLPolicy getOptimalPolicy() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public State[] getVictoryStates() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCurrentGeneralState() {
		// TODO Auto-generated method stub
		return "Current state: " // (the current state may be more than one state) + STATES.values()[currentState.getState()]
				+ " > Action: " + ACTIONS.values()[actionExecuted] + " > Next state: " // (the next state may be more than one state) + STATES.values()[nextState]
				+ " > reward: " + waitingReward;
	}

	@Override
	public State[] generateVictoryStates() {
		// TODO Auto-generated method stub
		return null;
	}

	// ===================================
	// AUXILIAR METHODS FOR GUI PURPOSES
	// ===================================
	@Override
	public GameMap getGameMap() {
		return null;
	}

	@Override
	public double getAgentLife() {
		return 0;
	}

	@Override
	public double getAgentFullLife() {
		return 0;
	}

	@Override
	public double getEnemyLife() {
		return 0;
	}

	@Override
	public double getEnemyFullLife() {
		return 0;
	}

	@Override
	public Point getAgentPosition() {
		return null;
	}

	@Override
	public State getCurrentState() {
		return null;
	}

	@Override
	public Action[] findLegalActions(State state) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public State getNextState(State state, int action) {
		return null;
	}

	@Override
	public boolean endState(State state) {
		return false;
	}

	@Override
	public void saveState() {

	}

	@Override
	public void resetToLastSavedState() {

	}

	@Override
	public RLWorld generateCopy() {
		// TODO Auto-generated method stub
		return null;
	}
}
