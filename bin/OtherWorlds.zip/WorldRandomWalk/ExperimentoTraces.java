package WorldRandomWalk;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.rosuda.REngine.Rserve.RConnection;

import Analysis.RCodeGenerator;
import Analysis.RLGraficar;
import Auxiliar.Helper;
import Output.Output;
import RL.RLearner;
import RL.RLearner.LEARNING_METHOD;
import RL.RLearner.SELECTION_METHOD;

public class ExperimentoTraces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Experimento
		int numeroDeExperimento = 0;
		String urlDelExperimento = Output.simulationPathExperimentosRandomWalkWorld[numeroDeExperimento];
		String descriptionDelExperimento = Output.simulationDescriptionExperimentosRandomWalkWorld[numeroDeExperimento];
		RL.RLearner.simulationPath = urlDelExperimento;
		RL.RLearner.simulationDescription = descriptionDelExperimento;

		// Ejecutar el experimento y crear las graficas
		boolean ejecutarExperimento = true;
		boolean crearGrafica = true;

		// ================================
		// EJECUCION DEL EXPERIMENTO
		// ================================
		if (ejecutarExperimento) {
			// ================================
			// STATES AND ACTIONS (if nothing is set, the actions and states will be the ones by default in the world)
			// ================================
			//Actions.Action[] actions = Actions.generateActions();
			//State[] states = MultiArmBanditWorld.generateStates(actions);

			// ================================
			// CONTANTS OF THE EXPERIMENT
			// ================================
			final double gamma = 0.1;
			final double epsilon = 0.1;
			final int totalTasks = 100; // total de tareas
			final int totalEpisodes = 10; // total de episodios por cada tarea
			LEARNING_METHOD learningMethod = LEARNING_METHOD.SARSA_LAMBDA;
			SELECTION_METHOD selectionMethod = SELECTION_METHOD.E_GREEDY;

			System.out.println("===========================");
			System.out.println("CONSTANTS OF THE EXPERIMENT");
			System.out.println("===========================");
			System.out.println("TOTAL TASKS: " + totalTasks);
			System.out.println("TOTAL EPISODES: " + totalEpisodes);
			System.out.println("GAMMA: " + gamma);
			System.out.println("EPSILON: " + epsilon);

			// ================================
			// PARAMETER THAT IS UNDER ANALISYS
			// ================================
			// PARAMETRO 1
			String nombreParametro1 = RLearner.LEARNING_PARAMETER.alphaLearningRate.name();
			int divisionesParametro1 = 2;
			double[] alphaValues = new double[divisionesParametro1];
			if (false) {
				alphaValues[0] = 0.0;
				alphaValues[1] = 0.4;
			} else {
				for (int i = 1; i <= divisionesParametro1; i++) {
					double aux = Helper.round((1.0 / (double) (divisionesParametro1)) * ((double) i),
							Output.maxDecimales);
					alphaValues[i - 1] = aux;
				}
			}

			// PARAMETRO 2 (THERE MAY NOT BE A SECOND PARAMETER TO EVALUATE)
			String nombreParametro2 = RLearner.LEARNING_PARAMETER.lambdaSteps.name();
			int divisionesParametro2 = 5;
			double[] lambdaValues = new double[divisionesParametro2];
			lambdaValues[0] = 0.95;
			if (false) {
				lambdaValues[0] = 0.0;
				lambdaValues[1] = 0.95;
			} else {
				for (int i = 1; i <= divisionesParametro2; i++) {
					double aux = Helper.round((1.0 / (double) (divisionesParametro2)) * ((double) i),
							Output.maxDecimales);
					lambdaValues[i - 1] = aux;
				}
			}

			// ================================
			// PERFORMANCE MEASURES
			// ================================
			double[][] performanceMeasures = new double[divisionesParametro1][divisionesParametro2];

			// ================================
			// THE LEARNER
			// ================================
			// Executing the algorithm for several parameter values
			Thread[] parametrizaciones = new Thread[alphaValues.length * lambdaValues.length]; // +1 = epsilon temporal, el codigo esta insertado manualmente abajo
			for (int i = 0; i < alphaValues.length; i++) {
				for (int j = 0; j < lambdaValues.length; j++) {
					int indiceParametro1 = i;
					int indiceParametro2 = j;
					int indice = i * lambdaValues.length + j;
					(parametrizaciones[indice] = new Thread() {
						public void run() {
							// ================================
							// THE WORLD
							// ================================
							RandomWalkWorld world = new RandomWalkWorld(null, null);

							// Executing the experiment
							executeExperiment(world, alphaValues, indiceParametro1, lambdaValues, indiceParametro2);
						}

						private void executeExperiment(RandomWalkWorld world, double[] experimentParameterValues1,
								int indiceParametro1, double[] experimentParameterValues2, int indiceParametro2) {
							String worldName = world.getClass().toString()
									.substring(world.getClass().toString().lastIndexOf(".") + 1);

							String nombreSimulacion = worldName + "_" + learningMethod.name() + "_"
									+ selectionMethod.name() + "_t" + totalTasks + "_ep" + totalEpisodes + "_eG"
									+ epsilon + "_lRate" + experimentParameterValues1[indiceParametro1] + "_backup"
									+ experimentParameterValues2[indiceParametro2];

							// ================================
							// SETTING THE EXPERIMENT'S PARAMETERS
							// ================================
							RLearner learner = new RLearner(nombreSimulacion, world);
							learner.setTasks(totalTasks);
							learner.setTotalEpisodes(totalEpisodes);
							learner.setEpsilon(epsilon);
							learner.setActionSelectionMethod(selectionMethod);
							learner.setLearningMethod(learningMethod);
							learner.setAlpha(experimentParameterValues1[indiceParametro1]); // for q-learning method (=1 for deterministic environments)
							learner.setGamma(gamma); // for q-learning method (=0 if only considering current rewards)
							learner.setLambda(experimentParameterValues2[indiceParametro2]);//learner.setLambda(0.001); // for TD(lambda) methods (=0 then we have a 1-step TD backup, = 1 then we have a Monte Carlo backup)

							// ================================
							// RUNNING THE REINFORCEMENT
							// LEARNING ALGORITHM
							// ================================
							learner.runTrial();

							// ==================================
							// PERFORMANCE MEASURES ARE CAPTURED
							// ==================================
							performanceMeasures[indiceParametro1][indiceParametro2] = ((new Mean())
									.evaluate(learner.performanceBasedOnRMSErrors));
							//System.out.println("RMSE(alpha=" + experimentParameterValues1[indiceParametro1] + "): " + performanceMeasures[indiceParametro1][indiceParametro2]);
						}
					}).start();
				}
			}

			// ==============================================================
			// AQUI ESPERAMOS A QUE TODAS LAS HEBRAS SE TERMINEN DE EJECUTAR
			// ==============================================================
			System.out.println("=================================");
			System.out.println("WAITING FOR THE EXECUTING THREADS");
			System.out.println("=================================");
			for (int i = 0; i < alphaValues.length; i++) {
				for (int j = 0; j < lambdaValues.length; j++) {
					int indice = i * lambdaValues.length + j;
					try {
						parametrizaciones[indice].join();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			// ===============================================================================
			// ALMACENAMOS LOS RESULTADOS DE RENDIMIENTO PARA LAS DIFERENTES PARAMETRIZACIONES
			// Nota: por cada parametrizacion se obtiene solo un unico dato, RMSE, que mide
			// el error producido de media entre la estimacion producida por el algoritmo
			// y la politica optima. Evidentemente, si se quiere obtener este dato ha de saberse
			// cual es la politica optima y, consecuentemente, implementarla en el objeto World.
			// ===============================================================================
			// Showing the results
			String performance = "";
			System.out.println("=================================================");
			performance = ";";
			for (int j = 0; j < lambdaValues.length; j++) {
				performance = performance + "(" + nombreParametro2 + "=" + lambdaValues[j] + ") ";
				performance = performance + (j + 1 == lambdaValues.length ? "" : ";");
			}
			performance = performance + "\n";

			for (int i = 0; i < alphaValues.length; i++) {
				performance = performance + "(" + nombreParametro1 + "=" + alphaValues[i] + "); ";
				for (int j = 0; j < lambdaValues.length; j++) {
					performance = performance + Helper.round(performanceMeasures[i][j], Output.maxDecimales);
					performance = performance + (j + 1 == lambdaValues.length ? "" : ";");
				}
				performance = performance + "\n";
			}
			System.out.println(performance);
			System.out.println("=================================================");
			try {
				Helper.writeToFile(performance,
						urlDelExperimento + "/" + Output.typeOfCharts.policyPerformance + ".csv");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// ================================
		// GRAFICAS DEL EXPERIMENTO
		// ================================
		if (crearGrafica) {
			System.out.println("======================");
			System.out.println("Creating the charts...");
			System.out.println("======================");
			boolean chooseFiles;
			RLGraficar graficar = new RLGraficar(chooseFiles = false);

			// Checking R connection with Rserve
			try {
				new RConnection();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Sep up Rserve: goes to R class Analysis->SetUpRserve.R and run it",
						"Rserve not setup", JOptionPane.ERROR_MESSAGE);
			}

			// File that must not be taken into account
			String[] specificFileToNotPlot = new String[] { Output.typeOfCharts.policyPerformance.name() };

			// Por algun extrano motivo Windows no realiza una nueva conexion para cada conexion con Rserve por lo que
			// no se puedan usar Threads en windows para maximizar la creacion de graficas
			if (RCodeGenerator.isOperativeSystemWindows()) {
				System.out.println("1");
				graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yAverageReward, null, null);
				System.out.println("2");
				graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yOptimalAction, null, null);
				System.out.println("3");
				graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yPercentageOfActions, null, null);
			} else {
				// AVERAGE REWARD
				new Thread() {

					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yAverageReward, null,
								specificFileToNotPlot);
					}
				}.start();

				// OPTIMAL ACTION
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yOptimalAction, null,
								specificFileToNotPlot);
					}
				}.start();

				// HISTOGRAM OF ACTIONS
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.xEpisode_yPercentageOfActions,
								null, specificFileToNotPlot);
					}
				}.start();

				// HISTOGRAM OF ACTIONS
				new Thread() {
					public void run() {
						graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.policyPerformance,
								Output.typeOfCharts.policyPerformance.name(), null);
					}
				}.start();
			}
		}

		if (false) {
			RLGraficar graficar = new RLGraficar(false);

			// HISTOGRAM OF ACTIONS
			new Thread() {
				public void run() {
					graficar.crearGrafica(urlDelExperimento, Output.typeOfCharts.policyPerformance,
							Output.typeOfCharts.policyPerformance.name(), null);
				}
			}.start();
		}
	}

}
